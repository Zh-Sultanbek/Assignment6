package factory;

public interface Button {
    public void render();
    public void onClick();
}

class WindowsButton implements Button {
    public void render(){}


    public void onClick() {}

}

class HTMLButton extends WindowsButton implements Button {
    public void render(){}

    public void onClick() {}
}