package factory;

public class Application {
    public static Object dialog;
    public void initialize() {}
    String config = void readApplicationConfigFile () {


            if (config.OS == "Windows") {

                dialog = new WindowsDialog();

            } else if (config.OS == "Web") {
                dialog = new WebDialog();
            } else {
                throw new Exception("Error! Unknown operating system.")
            }
        }

    public void main() {
        this.initialize();
        dialog.render();
        }
}

