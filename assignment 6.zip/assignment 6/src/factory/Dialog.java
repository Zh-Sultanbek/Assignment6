package factory;


abstract class Dialog {

    public WindowsButton createButton() {
        return null;
    }

    public void render() {
    }
}

    class WindowsDialog extends Dialog {
        public WindowsButton createButton() {
        return new WindowsButton();

        }
    }

    class WebDialog extends Dialog {
        public HTMLButton createButton(){

            return new HTMLButton();
        }
    }





