package com.company;

import java.sql.*;
public class Database {
    private static Database instance;
    String connectionUrl = "jdbc:postgresql://localhost:7852/postgres";
    Connection con = null;
    ResultSet rs = null;
    Statement stmt = null;
    private Database() {
    }
    public static Database getInstance() {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }
    public void query(String sql) {
        try
        {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl,"postgres","sula0113");
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
            while(rs.next())
            {
                System.out.println(rs.getInt("id") + " " + rs.getString("name") + " " + rs.getString("project") + " " + rs.getString("employee") + " " + rs.getInt("total"));
            }
        }
        catch (ClassNotFoundException | SQLException e)
        {
            e.printStackTrace();
        }
    }
}